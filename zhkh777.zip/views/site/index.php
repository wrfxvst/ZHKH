<?php

use yii\helpers\Html;

$this->title = 'Жилкомсервис 777';
?>
<div class="site-index">
    <div class="jumbotron">
        <h1>Жилкомсервис 777</h1>
        <p class="lead">Система управления заявками жильцов</p>
        
        <?php if (Yii::$app->user->isGuest): ?>
            <?= Html::a('Регистрация', ['/site/register'], ['class' => 'btn btn-success']) ?>
            <?= Html::a('Авторизация', ['/site/login'], ['class' => 'btn btn-primary']) ?>
        <?php else: ?>
            <p>Добро пожаловать, <?= Yii::$app->user->identity->fio ?>!</p>
            <?php if (Yii::$app->user->identity->isAdmin()): ?>
                <?= Html::a('Панель администратора', ['/admin'], ['class' => 'btn btn-primary']) ?>
            <?php else: ?>
                <?= Html::a('Мои заявки', ['/account/application'], ['class' => 'btn btn-primary']) ?>
                <?= Html::a('Создать заявку', ['/account/application/create'], ['class' => 'btn btn-success']) ?>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>