<?php

use yii\helpers\Html;

?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <link href="<?= Yii::getAlias('@web/css/site.css') ?>" rel="stylesheet">
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>

<div class="wrap">
    <header class="header">
        <div class="container">
            <div class="header-inner">
                <a href="<?= Yii::$app->homeUrl ?>" class="logo">ЖКХ777</a>
                
                <nav class="main-nav">
                    <a href="<?= Yii::$app->homeUrl ?>">Главная</a>
                    
                    <?php if (Yii::$app->user->isGuest): ?>
                        <a href="<?= \yii\helpers\Url::to(['/site/register']) ?>">Регистрация</a>
                        <a href="<?= \yii\helpers\Url::to(['/site/login']) ?>">Авторизация</a>
                    <?php else: ?>
                        <?php if (isset(Yii::$app->user->identity) && Yii::$app->user->identity->isAdmin()): ?>
                            <a href="<?= \yii\helpers\Url::to(['/admin']) ?>">Панель администратора</a>
                        <?php else: ?>
                            <a href="<?= \yii\helpers\Url::to(['/account/application/index']) ?>">Мои заявки</a>
                        <?php endif; ?>
                        
                        <form action="<?= \yii\helpers\Url::to(['/site/logout']) ?>" method="post" class="logout-form">
                            <input type="hidden" name="<?= Yii::$app->request->csrfParam ?>" value="<?= Yii::$app->request->csrfToken ?>">
                            <button type="submit" class="logout-btn">Выйти (<?= Yii::$app->user->identity->login ?>)</button>
                        </form>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </header>

    <main class="main">
        <div class="container">
            <?= $this->render('_alerts') ?>
            <?= $content ?>
        </div>
    </main>
</div>

<footer class="footer">
    <div class="container">
        <p>&copy; Жилкомсервис 777 <?= date('Y') ?></p>
    </div>
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>