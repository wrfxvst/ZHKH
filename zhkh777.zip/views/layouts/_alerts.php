<?php
use yii\helpers\Html;

$session = Yii::$app->session;
$flashes = $session->getAllFlashes();
$alertTypes = [
    'error'   => 'alert-error',
    'danger'  => 'alert-danger',
    'success' => 'alert-success',
    'info'    => 'alert-info',
    'warning' => 'alert-warning'
];

foreach ($flashes as $type => $data) {
    if (isset($alertTypes[$type])) {
        $data = (array) $data;
        foreach ($data as $message) {
            echo '<div class="alert ' . $alertTypes[$type] . '">';
            echo Html::encode($message);
            echo '<button type="button" class="alert-close" onclick="this.parentElement.style.display=\'none\'">&times;</button>';
            echo '</div>';
        }
        $session->removeFlash($type);
    }
}
?>