<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property string $name
 */
class Profession extends ActiveRecord
{
    public static function tableName()
    {
        return 'profession';
    }

    public function rules()
    {
        return [
            [['name'], 'required'],
            [['name'], 'string', 'max' => 255],
        ];
    }

    public function attributeLabels()
    {
        return [
            'name' => 'Название профиля',
        ];
    }

    public function getApplications()
    {
        return $this->hasMany(Application::class, ['profession_id' => 'id']);
    }
}