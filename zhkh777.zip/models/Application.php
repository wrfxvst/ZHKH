<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property int $user_id
 * @property int $profession_id
 * @property string $title
 * @property string $description
 * @property string $status
 * @property string $cancel_reason
 * @property string $created_at
 * @property string $updated_at
 */
class Application extends ActiveRecord
{
    const STATUS_NEW = 'Новая';
    const STATUS_IN_WORK = 'В работе';
    const STATUS_DONE = 'Выполнена';
    const STATUS_CANCELED = 'Отменена';

    public static function tableName()
    {
        return 'application';
    }

    public function rules()
    {
        return [
            [['title', 'description', 'profession_id'], 'required'],
            [['description', 'cancel_reason'], 'string'],
            [['user_id', 'profession_id'], 'integer'],
            [['title'], 'string', 'max' => 255],
            [['status'], 'string', 'max' => 50],
            [['status'], 'default', 'value' => self::STATUS_NEW],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'Пользователь',
            'profession_id' => 'Профиль специалиста',
            'title' => 'Наименование заявки',
            'description' => 'Содержание заявки',
            'status' => 'Статус',
            'cancel_reason' => 'Причина отмены',
            'created_at' => 'Дата создания',
            'updated_at' => 'Дата обновления',
        ];
    }

    public function beforeSave($insert)
    {
        if ($insert) {
            $this->user_id = Yii::$app->user->id;
        }
        return parent::beforeSave($insert);
    }

    public function getUser()
    {
        return $this->hasOne(User::class, ['id' => 'user_id']);
    }

    public function getProfession()
    {
        return $this->hasOne(Profession::class, ['id' => 'profession_id']);
    }

    public function canBeModified()
    {
        return $this->status === self::STATUS_NEW;
    }

    public function cancel($reason = null)
    {
        $this->status = self::STATUS_CANCELED;
        $this->cancel_reason = $reason;
        return $this->save();
    }
}