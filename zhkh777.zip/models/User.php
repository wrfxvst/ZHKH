<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;

/**
 * @property int $id
 * @property string $fio
 * @property string $login
 * @property string $email
 * @property string $phone
 * @property string $password
 * @property string $address
 * @property string $role
 * @property string $created_at
 */
class User extends ActiveRecord implements IdentityInterface
{
    const ROLE_USER = 'user';
    const ROLE_ADMIN = 'admin';

    public $password_repeat;

    public static function tableName()
    {
        return 'user';
    }

    public function rules()
    {
        return [
            [['fio', 'login', 'email', 'phone', 'password', 'address'], 'required'],
            [['fio'], 'match', 'pattern' => '/^[а-яА-ЯёЁ\s\-]+$/u', 'message' => 'ФИО должно содержать только кириллические буквы, дефис и пробелы'],
            [['login'], 'match', 'pattern' => '/^[a-zA-Z\-]+$/', 'message' => 'Логин должен содержать только латиницу и дефис'],
            [['login'], 'unique', 'message' => 'Этот логин уже занят'],
            [['email'], 'email', 'message' => 'Некорректный формат email'],
            [['email'], 'unique', 'message' => 'Этот email уже занят'],
            [['phone'], 'match', 'pattern' => '/^\+7-\([0-9]{3}\)-[0-9]{3}-[0-9]{2}-[0-9]{2}$/', 'message' => 'Телефон должен быть в формате +7-(XXX)-XXX-XX-XX'],
            [['password'], 'match', 'pattern' => '/^(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]{8,}$/', 'message' => 'Пароль должен содержать минимум 8 символов, 1 заглавную букву и 1 цифру'],
            [['address'], 'string'],
            [['role'], 'string', 'max' => 10],
            [['role'], 'default', 'value' => self::ROLE_USER],
        ];
    }

    public function attributeLabels()
    {
        return [
            'fio' => 'ФИО',
            'login' => 'Логин',
            'email' => 'Email',
            'phone' => 'Телефон',
            'password' => 'Пароль',
            'address' => 'Адрес проживания',
            'role' => 'Роль',
        ];
    }

    public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            if ($this->isNewRecord) {
                $this->password = Yii::$app->security->generatePasswordHash($this->password);
            }
            return true;
        }
        return false;
    }

    // IdentityInterface methods
    public static function findIdentity($id)
    {
        return static::findOne($id);
    }

    public static function findIdentityByAccessToken($token, $type = null)
    {
        return null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getAuthKey()
    {
        return null;
    }

    public function validateAuthKey($authKey)
    {
        return false;
    }

    public static function findByUsername($username)
    {
        return static::findOne(['login' => $username]);
    }

    public function validatePassword($password)
    {
        return Yii::$app->security->validatePassword($password, $this->password);
    }

    public function getApplications()
    {
        return $this->hasMany(Application::class, ['user_id' => 'id']);
    }

    // Новые методы для проверки ролей
    public function isAdmin()
    {
        return $this->role === self::ROLE_ADMIN;
    }

    public function isUser()
    {
        return $this->role === self::ROLE_USER;
    }

    // Метод для получения списка ролей
    public static function getRoles()
    {
        return [
            self::ROLE_USER => 'Пользователь',
            self::ROLE_ADMIN => 'Администратор',
        ];
    }
}