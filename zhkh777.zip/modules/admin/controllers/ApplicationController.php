<?php

namespace app\modules\admin\controllers;

use Yii;
use app\models\Application;
use app\models\Profession;
use yii\data\ActiveDataProvider;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

class ApplicationController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function actionIndex()
    {
        $dataProvider = new ActiveDataProvider([
            'query' => Application::find()->with('user', 'profession')->orderBy(['created_at' => SORT_DESC]),
        ]);

        return $this->render('index', [
            'dataProvider' => $dataProvider,
        ]);
    }

    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    public function actionConfirm($id)
    {
        $model = $this->findModel($id);
        $model->status = Application::STATUS_IN_WORK;
        
        if ($model->save()) {
            Yii::$app->session->setFlash('success', 'Заявка подтверждена.');
        } else {
            Yii::$app->session->setFlash('error', 'Ошибка при подтверждении заявки.');
        }

        return $this->redirect(['view', 'id' => $model->id]);
    }

    public function actionComplete($id)
    {
        $model = $this->findModel($id);
        $model->status = Application::STATUS_DONE;
        
        if ($model->save()) {
            Yii::$app->session->setFlash('success', 'Заявка отмечена как выполненная.');
        } else {
            Yii::$app->session->setFlash('error', 'Ошибка при обновлении статуса заявки.');
        }

        return $this->redirect(['view', 'id' => $model->id]);
    }

    public function actionCancel($id)
    {
        $model = $this->findModel($id);

        if (Yii::$app->request->isPost) {
            $reason = Yii::$app->request->post('cancel_reason');
            if ($model->cancel($reason)) {
                Yii::$app->session->setFlash('success', 'Заявка отменена.');
            } else {
                Yii::$app->session->setFlash('error', 'Ошибка при отмене заявки.');
            }
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('cancel', [
            'model' => $model,
        ]);
    }

    protected function findModel($id)
    {
        if (($model = Application::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('Заявка не найдена.');
    }
}