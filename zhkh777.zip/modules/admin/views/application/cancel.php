<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Отмена заявки: ' . $model->title;
$this->params['breadcrumbs'][] = ['label' => 'Управление заявками', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->title, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Отмена';
?>
<div class="application-cancel">
    <h1><?= Html::encode($this->title) ?></h1>

    <div class="alert alert-warning">
        <strong>Внимание!</strong> Вы собираетесь отменить заявку. Пожалуйста, укажите причину отмены.
    </div>

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'cancel_reason')->textarea(['rows' => 6])->label('Причина отмены') ?>

    <div class="form-group">
        <?= Html::submitButton('Отменить заявку', ['class' => 'btn btn-warning']) ?>
        <?= Html::a('Назад', ['view', 'id' => $model->id], ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>