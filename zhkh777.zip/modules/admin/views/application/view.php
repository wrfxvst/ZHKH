<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

$this->title = $model->title;
$this->params['breadcrumbs'][] = ['label' => 'Управление заявками', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="application-view">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?php if ($model->status === \app\models\Application::STATUS_NEW): ?>
            <?= Html::a('Подтвердить', ['confirm', 'id' => $model->id], [
                'class' => 'btn btn-success',
                'data' => [
                    'confirm' => 'Подтвердить эту заявку?',
                    'method' => 'post',
                ],
            ]) ?>
        <?php endif; ?>
        
        <?php if ($model->status === \app\models\Application::STATUS_IN_WORK): ?>
            <?= Html::a('Выполнено', ['complete', 'id' => $model->id], [
                'class' => 'btn btn-info',
                'data' => [
                    'confirm' => 'Отметить как выполненную?',
                    'method' => 'post',
                ],
            ]) ?>
        <?php endif; ?>
        
        <?php if (in_array($model->status, [\app\models\Application::STATUS_NEW, \app\models\Application::STATUS_IN_WORK])): ?>
            <?= Html::a('Отменить', ['cancel', 'id' => $model->id], ['class' => 'btn btn-warning']) ?>
        <?php endif; ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            [
                'attribute' => 'user_id',
                'value' => $model->user->fio,
            ],
            [
                'attribute' => 'user_id',
                'label' => 'Телефон',
                'value' => $model->user->phone,
            ],
            [
                'attribute' => 'user_id',
                'label' => 'Email',
                'value' => $model->user->email,
            ],
            'title',
            [
                'attribute' => 'profession_id',
                'value' => $model->profession->name,
            ],
            'description:ntext',
            'status',
            'cancel_reason:ntext',
            'created_at',
            'updated_at',
        ],
    ]) ?>

</div>