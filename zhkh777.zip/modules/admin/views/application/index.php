<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;

$this->title = 'Управление заявками';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="application-index">
    <h1><?= Html::encode($this->title) ?></h1>

    <?php Pjax::begin(); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            [
                'attribute' => 'user_id',
                'value' => function($model) {
                    return $model->user->fio;
                }
            ],
            'title',
            [
                'attribute' => 'profession_id',
                'value' => function($model) {
                    return $model->profession->name;
                }
            ],
            'status',
            'created_at',

            [
                'class' => 'yii\grid\ActionColumn',
                'template' => '{view} {confirm} {complete} {cancel}',
                'buttons' => [
                    'confirm' => function($url, $model, $key) {
                        if ($model->status === \app\models\Application::STATUS_NEW) {
                            return Html::a('Подтвердить', ['confirm', 'id' => $model->id], [
                                'class' => 'btn btn-xs btn-success',
                                'data' => [
                                    'confirm' => 'Подтвердить эту заявку?',
                                    'method' => 'post',
                                ],
                            ]);
                        }
                        return '';
                    },
                    'complete' => function($url, $model, $key) {
                        if ($model->status === \app\models\Application::STATUS_IN_WORK) {
                            return Html::a('Выполнено', ['complete', 'id' => $model->id], [
                                'class' => 'btn btn-xs btn-info',
                                'data' => [
                                    'confirm' => 'Отметить как выполненную?',
                                    'method' => 'post',
                                ],
                            ]);
                        }
                        return '';
                    },
                    'cancel' => function($url, $model, $key) {
                        if (in_array($model->status, [\app\models\Application::STATUS_NEW, \app\models\Application::STATUS_IN_WORK])) {
                            return Html::a('Отменить', ['cancel', 'id' => $model->id], [
                                'class' => 'btn btn-xs btn-warning',
                            ]);
                        }
                        return '';
                    }
                ],
            ],
        ],
    ]); ?>

    <?php Pjax::end(); ?>
</div>