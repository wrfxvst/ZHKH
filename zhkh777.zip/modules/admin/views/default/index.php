<?php
use yii\helpers\Html;
?>
<div class="admin-default-index">
    <h1>Панель администратора</h1>
    <p>Добро пожаловать в панель администратора!</p>
    
    <div class="row">
        <div class="col-md-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Заявки</h3>
                </div>
                <div class="panel-body">
                    <p>Управление заявками пользователей</p>
                    <?= Html::a('Управление заявками', ['/admin/application'], ['class' => 'btn btn-primary']) ?>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Профили специалистов</h3>
                </div>
                <div class="panel-body">
                    <p>Управление профилями специалистов</p>
                    <?= Html::a('Управление профилями', ['/admin/profession'], ['class' => 'btn btn-primary']) ?>
                </div>
            </div>
        </div>
    </div>
</div>