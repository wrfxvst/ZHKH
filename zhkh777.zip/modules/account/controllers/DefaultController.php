<?php

namespace app\modules\account\controllers;

use yii\web\Controller;

class DefaultController extends Controller
{
    public function actionIndex()
    {
        return $this->redirect(['application/index']);
    }
}