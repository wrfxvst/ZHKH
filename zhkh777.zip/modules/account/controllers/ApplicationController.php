<?php

namespace app\modules\account\controllers;

use Yii;
use app\models\Application;
use app\models\Profession;
use yii\data\ActiveDataProvider;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;

class ApplicationController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['POST'],
                    'cancel' => ['POST'],
                ],
            ],
        ];
    }

    public function actionIndex()
    {
        $dataProvider = new ActiveDataProvider([
            'query' => Application::find()->where(['user_id' => Yii::$app->user->id])->orderBy(['created_at' => SORT_DESC]),
        ]);

        return $this->render('index', [
            'dataProvider' => $dataProvider,
        ]);
    }

    public function actionView($id)
    {
        $model = $this->findModel($id);
        
        // Проверка, что пользователь просматривает свою заявку
        if ($model->user_id !== Yii::$app->user->id) {
            throw new NotFoundHttpException('У вас нет доступа к этой странице.');
        }

        return $this->render('view', [
            'model' => $model,
        ]);
    }

    public function actionCreate()
    {
        $model = new Application();

        $professions = Profession::find()
            ->select(['name'])
            ->indexBy('id')
            ->column();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Заявка успешно создана.');
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
            'professions' => $professions,
        ]);
    }

    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        
        // Проверка, что пользователь редактирует свою заявку и она может быть изменена
        if ($model->user_id !== Yii::$app->user->id || !$model->canBeModified()) {
            throw new NotFoundHttpException('Вы не можете редактировать эту заявку.');
        }

        $professions = Profession::find()
            ->select(['name'])
            ->indexBy('id')
            ->column();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Заявка успешно обновлена.');
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
            'professions' => $professions,
        ]);
    }

    public function actionDelete($id)
    {
        $model = $this->findModel($id);
        
        // Проверка, что пользователь удаляет свою заявку и она может быть изменена
        if ($model->user_id !== Yii::$app->user->id || !$model->canBeModified()) {
            throw new NotFoundHttpException('Вы не можете удалить эту заявку.');
        }

        $model->delete();
        Yii::$app->session->setFlash('success', 'Заявка успешно удалена.');

        return $this->redirect(['index']);
    }

    public function actionCancel($id)
    {
        $model = $this->findModel($id);
        
        // Проверка, что пользователь отменяет свою заявку и она может быть изменена
        if ($model->user_id !== Yii::$app->user->id || !$model->canBeModified()) {
            throw new NotFoundHttpException('Вы не можете отменить эту заявку.');
        }

        if ($model->cancel()) {
            Yii::$app->session->setFlash('success', 'Заявка успешно отменена.');
        } else {
            Yii::$app->session->setFlash('error', 'Ошибка при отмене заявки.');
        }

        return $this->redirect(['view', 'id' => $model->id]);
    }

    protected function findModel($id)
    {
        if (($model = Application::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('Заявка не найдена.');
    }
}