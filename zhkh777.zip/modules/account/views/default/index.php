<?php
use yii\helpers\Html;
?>
<div class="account-default-index">
    <h1>Личный кабинет</h1>
    <p>Добро пожаловать в личный кабинет!</p>
    
    <?= Html::a('Мои заявки', ['/account/application'], ['class' => 'btn btn-primary']) ?>
    <?= Html::a('Создать заявку', ['/account/application/create'], ['class' => 'btn btn-success']) ?>
</div>