<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;

$this->title = 'Мои заявки';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="application-index">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Создать заявку', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php Pjax::begin(); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'title',
            [
                'attribute' => 'profession_id',
                'value' => function($model) {
                    return $model->profession->name;
                }
            ],
            'status',
            'created_at',

            [
                'class' => 'yii\grid\ActionColumn',
                'template' => '{view} {update} {delete} {cancel}',
                'buttons' => [
                    'cancel' => function($url, $model, $key) {
                        if ($model->canBeModified()) {
                            return Html::a('Отменить', ['cancel', 'id' => $model->id], [
                                'class' => 'btn btn-xs btn-warning',
                                'data' => [
                                    'confirm' => 'Вы уверены, что хотите отменить эту заявку?',
                                    'method' => 'post',
                                ],
                            ]);
                        }
                        return '';
                    }
                ],
            ],
        ],
    ]); ?>

    <?php Pjax::end(); ?>
</div>