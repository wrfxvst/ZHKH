<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

?>

<div class="application-form">
    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'title')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'profession_id')->dropDownList(
        $professions,
        ['prompt' => 'Выберите специалиста']
    ) ?>

    <?= $form->field($model, 'description')->textarea(['rows' => 6]) ?>

    <div class="form-group">
        <?= Html::submitButton('Сохранить', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>